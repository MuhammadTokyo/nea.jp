<?php include 'nav.php';?>
<link rel="stylesheet" href="/css/senden.css">


<div class="container">
<div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active c-i1 w-100" data-bs-interval="1">
      <img src="img/17.png" class="d-block w-100" alt="logo">
    </div>
    <div class="carousel-item c-i2" data-bs-interval="1">
      <img src="img/17.png" class="d-block w-100" alt="logo">
    </div>
    <div class="carousel-item c-i3" data-bs-interval="1">
      <img src="img/17.png" class="d-block w-100" alt="logo">
    </div>
  </div>
</div>
</div>


<?php include 'footer.php';?>